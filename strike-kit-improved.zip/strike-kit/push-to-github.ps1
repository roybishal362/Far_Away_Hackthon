# One-shot GitHub push helper (personal account: roybishal362)
# WHY: the laptop's cached git login is the company account, which can't write
# to your personal repo. This pushes using YOUR token, then removes the token
# from git config so it never persists or gets committed.
#
# STEP 1 (one time): create a token (classic) with the "repo" scope at:
#         https://github.com/settings/tokens
# STEP 2: run this script and paste the token when asked.

$repo  = "c:\Users\DELL\Documents\FAR\strike-kit"
$clean = "https://github.com/roybishal362/Far_Away_Hackthon.git"

$token = Read-Host "Paste your GitHub token (roybishal362)"
$auth  = "https://roybishal362:$token@github.com/roybishal362/Far_Away_Hackthon.git"

git -C $repo remote set-url origin $auth
try {
    git -C $repo branch -M main
    git -C $repo push -u origin main
}
finally {
    # Always restore the token-free URL, even if the push fails.
    git -C $repo remote set-url origin $clean
    Write-Host "`nToken removed from git config. Remote is clean." -ForegroundColor Green
}
